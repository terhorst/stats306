PEW RESEARCH CENTER FOR SOCIAL& DEMOGRAPHIC TRENDS

January 2010 Millennial Survey (January 14-27,2010)

Interviews were conducted in English and Spanish.

National sample: N=2,020

***Note: The WEIGHT variable is weighting variable intended for use on all questions.

***Note for variables: Race of the respondent "Race1" allows multiple responses, 
and "racecmb" in the dataset combines different responses to the race questions.
The combined variable �racethn� identifies the respondent�s race and ethnicity. 


******************************************************************************************************************************************

The Pew Research Center uses respondents� self-reported zip code as the basis for geographic variables such as region,state and county. 
We continue to include the original sample geographic variables in the datasets (these variables are preceded by an �s�)
for archival purposes only.

To protect the privacy of respondents, telephone numbers, zip code and other identifying variables have been removed from
the public data file.

Some special technical variables were also removed, but are available upon request.

******************************************************************************************************************************************
